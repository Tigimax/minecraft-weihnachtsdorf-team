# Moves the item from the offhand to the plant
data modify entity @e[tag=af.selected_plant,distance=..10,limit=1] block_state.id set from entity @s SelectedItem.id
execute if items entity @s weapon.mainhand #af.base:tall_plant run data modify entity @e[tag=af.selected_plant_top,distance=..10,limit=1] block_state.id set from entity @s SelectedItem.id
execute if items entity @s weapon.mainhand #af.base:tall_plant run data modify entity @e[tag=af.selected_plant_top,distance=..10,limit=1] block_state.properties.half set value "upper"

# Create empty storage to use as an argument
data modify storage af.base:argument lower_plant set value {id:"minecraft:air",properties:{}}
data modify storage af.base:argument upper_plant set value {id:"minecraft:air",properties:{}}
# Store the item that will be used for the upper and lower plants
data modify storage af.base:argument lower_plant.id set from entity @s SelectedItem.id
execute if items entity @s weapon.mainhand #af.base:tall_plant run data modify storage af.base:argument upper_plant.id set from entity @s SelectedItem.id
# Set half properties for top and bottom plants
execute if items entity @s weapon.mainhand #af.base:tall_plant run data modify storage af.base:argument lower_plant.properties.half set value "lower"
execute if items entity @s weapon.mainhand #af.base:tall_plant run data modify storage af.base:argument upper_plant.properties.half set value "upper"

## Special Cases
# Bamboo
execute if items entity @s weapon.mainhand bamboo run data modify storage af.base:argument lower_plant set value {id:"minecraft:bamboo",properties:{age:"0",leaves:"small"}}
execute if items entity @s weapon.mainhand bamboo run data modify storage af.base:argument upper_plant set value {id:"minecraft:bamboo",properties:{age:"0",leaves:"large"}}
# Pitcher Pod
execute if items entity @s weapon.mainhand pitcher_pod run data modify storage af.base:argument lower_plant set value {id:"pitcher_crop",properties:{age:"1"}}
# Pitcher Pod
execute if items entity @s weapon.mainhand small_dripleaf run data modify storage af.base:argument lower_plant set value {id:"small_dripleaf",properties:{half:"lower"}}
execute if items entity @s weapon.mainhand small_dripleaf run data modify storage af.base:argument upper_plant set value {id:"small_dripleaf",properties:{half:"upper"}}
# Chorus Flower
execute if items entity @s weapon.mainhand chorus_flower run data modify storage af.base:argument lower_plant set value {id:"chorus_plant",properties:{down:"true",up:"true"}}
execute if items entity @s weapon.mainhand chorus_flower run data modify storage af.base:argument upper_plant set value {id:"chorus_flower",properties:{age:"0"}}
# Sweet Berries
execute if items entity @s weapon.mainhand sweet_berries run data modify storage af.base:argument lower_plant set value {id:"sweet_berry_bush",properties:{age:"3"}}
# Crops
execute if items entity @s weapon.mainhand wheat_seeds run data modify storage af.base:argument lower_plant set value {id:"wheat",properties:{age:"7"}}
execute if items entity @s weapon.mainhand beetroot_seeds run data modify storage af.base:argument lower_plant set value {id:"beetroots",properties:{age:"3"}}
execute if items entity @s weapon.mainhand carrot run data modify storage af.base:argument lower_plant set value {id:"carrots",properties:{age:"7"}}
execute if items entity @s weapon.mainhand potato run data modify storage af.base:argument lower_plant set value {id:"potatoes",properties:{age:"7"}}
execute if items entity @s weapon.mainhand melon_seeds run data modify storage af.base:argument lower_plant set value {id:"melon_stem",properties:{age:"7"}}
execute if items entity @s weapon.mainhand pumpkin_seeds run data modify storage af.base:argument lower_plant set value {id:"pumpkin_stem",properties:{age:"7"}}

# Apply the data to the plant items
execute as @e[tag=af.selected_plant,limit=1,distance=..10] run data modify entity @s block_state set from storage af.base:argument lower_plant
execute as @e[tag=af.selected_plant_top,limit=1,distance=..10] run data modify entity @s block_state set from storage af.base:argument upper_plant

# Remove the collected data from storage
data remove storage af.base:argument lower_plant
data remove storage af.base:argument upper_plant

data modify entity @e[tag=af.selected_plant,distance=..10,limit=1] data."minecraft:custom_data".item set from entity @s SelectedItem
data modify entity @e[tag=af.selected_plant,distance=..10,limit=1] data."minecraft:custom_data".item.count set value 1

# Fanfare
playsound minecraft:block.decorated_pot.insert block @a ~ ~ ~ 1 1

# Removes an item
execute as @s[gamemode=!creative] run function af.base:item/remove_mainhand

# Tag self with has plant
tag @e[tag=af.selected_plant,distance=..10,limit=1] add af.has_plant