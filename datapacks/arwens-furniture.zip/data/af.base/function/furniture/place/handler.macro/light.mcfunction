# Sets the light level of the lit block
$setblock ~ ~ ~ light[level=$(light_level)]