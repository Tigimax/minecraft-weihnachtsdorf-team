# If no block, place light level of 3
data modify storage af.base:argument light_level set from storage af.base:furniture held_item.components."minecraft:custom_data".light_level
execute if block ~ ~ ~ #af.base:replaceable run function af.base:furniture/place/handler.macro/light with storage af.base:argument
data remove storage af.base:argument light_level
tag @e[tag=af.furniture_interaction,tag=af.new,type=interaction,distance=..10] add af.light_interaction