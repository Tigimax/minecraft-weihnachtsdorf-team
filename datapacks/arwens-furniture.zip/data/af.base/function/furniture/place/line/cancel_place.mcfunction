# Remove marker
function af.base:furniture/place/line/remove_marker

# Fanfare
title @s actionbar [{"text":"Stopped","color":"#baa7ff"},{"text":" placing line.","color":"#ffffff"}]
playsound minecraft:block.note_block.hat player @s ~ ~ ~ 1 1.75