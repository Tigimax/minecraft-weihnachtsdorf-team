# Create a new link
execute if score #links af.placement_data matches 2.. run function af.base:furniture/place/line/create/full with storage af.base:argument
execute if score #links af.placement_data matches 1 run function af.base:furniture/place/line/create/part with storage af.base:argument
# Assign the furniture id
execute as @e[tag=af.new_cast,sort=nearest,type=item_display] run function af.base:furniture/place/line/create/as_link

# Remove one from links, then run the function again
scoreboard players remove #links af.placement_data 1
$execute if score #links af.placement_data matches 1.. positioned ^ ^ ^$(line_length) run function af.base:furniture/place/line/cast with storage af.base:argument