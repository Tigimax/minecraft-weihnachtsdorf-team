# Set up the cast for creating the line
# At both placement markers, create a new furniture interaction
$summon interaction $(pos0_x) $(pos0_y) $(pos0_z) {Tags:["af.new","af.furniture_interaction","af.furniture","af.line_interaction","af.furniture.26.3"],response:1b,height:1,width:1}
$summon interaction $(pos1_x) $(pos1_y) $(pos1_z) {Tags:["af.new","af.furniture_interaction","af.furniture","af.line_interaction","af.furniture.26.3"],response:1b,height:1,width:1}
execute as @e[tag=af.new,tag=af.furniture_interaction,type=interaction] at @s run function af.base:furniture/place/line/create/interaction with storage af.base:furniture held_item.components."minecraft:custom_data"

# Start the cast
$execute positioned $(pos0_x) $(pos0_y) $(pos0_z) facing $(pos1_x) $(pos1_y) $(pos1_z) run function af.base:furniture/place/line/cast with storage af.base:argument