# Assign the furniture id
scoreboard players operation @s af.furniture_id = #current_id af.furniture_id
# Rotate facing the right direciton
tp @s ~ ~ ~ facing ^ ^ ^-1
# Remove new tag
tag @s remove af.new_cast