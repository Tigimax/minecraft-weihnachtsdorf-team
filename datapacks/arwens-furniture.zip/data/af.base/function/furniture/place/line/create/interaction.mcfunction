# Move self
$tp @s ~ ~$(interaction_translation_y) ~
# Modify height and width
$data modify entity @s width set value $(interaction_width)
$data modify entity @s height set value $(interaction_height)
# Set item data of interaction to held item
data modify entity @s data.item set from storage af.base:furniture held_item
data modify entity @s data.item.count set value 1

# Fanfare
playsound block.chain.place block @a ~ ~ ~ 1 1