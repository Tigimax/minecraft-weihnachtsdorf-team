# Select size of last link
execute if score #last_length af.placement_data matches 1 run data modify storage af.base:argument last_size set value "0.5"
execute if score #last_length af.placement_data matches 2 run data modify storage af.base:argument last_size set value "1.0"
execute if score #last_length af.placement_data matches 3 run data modify storage af.base:argument last_size set value "1.5"
execute if score #last_length af.placement_data matches 4 run data modify storage af.base:argument last_size set value "2.0"
execute if score #last_length af.placement_data matches 5 run data modify storage af.base:argument last_size set value "2.5"
execute if score #last_length af.placement_data matches 6 run data modify storage af.base:argument last_size set value "3.0"
execute if score #last_length af.placement_data matches 7 run data modify storage af.base:argument last_size set value "3.5"
execute if score #last_length af.placement_data matches 8 run data modify storage af.base:argument last_size set value "4.0"
execute if score #last_length af.placement_data matches 9 run data modify storage af.base:argument last_size set value "4.5"
execute if score #last_length af.placement_data matches 10 run data modify storage af.base:argument last_size set value "5.0"
execute if score #last_length af.placement_data matches 11 run data modify storage af.base:argument last_size set value "5.5"
execute if score #last_length af.placement_data matches 12 run data modify storage af.base:argument last_size set value "6.0"
execute if score #last_length af.placement_data matches 13 run data modify storage af.base:argument last_size set value "6.5"
execute if score #last_length af.placement_data matches 14 run data modify storage af.base:argument last_size set value "7.0"
execute if score #last_length af.placement_data matches 15 run data modify storage af.base:argument last_size set value "7.5"
execute if score #last_length af.placement_data matches 16 run data modify storage af.base:argument last_size set value "full"
# Call part with macro
function af.base:furniture/place/line/create/part.macro with storage af.base:argument
# Remove storage
data remove storage af.base:argument last_size