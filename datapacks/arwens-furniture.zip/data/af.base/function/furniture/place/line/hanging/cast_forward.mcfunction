# Create item model
$summon item_display ~ ~$(hanging_offset) ~ {Tags:["af.new","af.furniture_display","af.furniture","af.line_hanging"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"$(hanging_model)"}},transformation:{scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.0f,0.0f],left_rotation:{axis:[0.0,1.0,0.0],angle:0.0f},right_rotation:{axis:[0.0,1.0,0.0],angle:0.0f}}}

# Remove one from range
scoreboard players remove #hanging_count af.placement_data 1
# Cast backward
$execute if score #hanging_count af.placement_data matches 1.. positioned ^ ^ ^$(hanging_distance) run function af.base:furniture/place/line/hanging/cast_forward with storage af.base:argument