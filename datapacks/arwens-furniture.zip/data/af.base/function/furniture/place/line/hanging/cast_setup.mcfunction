# Summon a new hanging item
$summon item_display ~ ~$(hanging_offset) ~ {Tags:["af.new","af.furniture_display","af.furniture","af.line_hanging"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"$(hanging_model)"}},transformation:{scale:[1.0f,1.0f,1.0f],translation:[0.0f,0.0f,0.0f],left_rotation:{axis:[0.0,1.0,0.0],angle:0.0f},right_rotation:{axis:[0.0,1.0,0.0],angle:0.0f}}}

# Create temporary cast variable
$scoreboard players set #hanging_count af.placement_data $(hanging_count)
# Cast forward with storage
$execute unless score #hanging_count af.placement_data matches ..0 positioned ^ ^ ^$(hanging_distance) run function af.base:furniture/place/line/hanging/cast_forward with storage af.base:argument

# Create temporary cast variable
$scoreboard players set #hanging_count af.placement_data $(hanging_count)
# Cast forward with storage
$execute unless score #hanging_count af.placement_data matches ..0 positioned ^ ^ ^-$(hanging_distance) run function af.base:furniture/place/line/hanging/cast_backward with storage af.base:argument

# Place lights at all hanging lanterns
$execute as @e[tag=af.new,tag=af.line_hanging] at @s if block ~ ~ ~ #af.base:replaceable run setblock ~ ~ ~ light[level=$(hanging_light_level)]