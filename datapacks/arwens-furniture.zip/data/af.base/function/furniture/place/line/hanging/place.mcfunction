# Get the distance between hanging items from the item data
data modify storage af.base:argument hanging_distance set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.hanging_distance
# Calculate the number of hanging items that can be added from the center
data modify storage af.base:argument hanging_count set compute default float af.base:line/hanging_count
# Convert to integer
execute store result storage af.base:argument hanging_count int 1.01 run data get storage af.base:argument hanging_count
# Get the y offset for hanging items
data modify storage af.base:argument hanging_offset set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.hanging_offset
# Get hanging light level
data modify storage af.base:argument hanging_light_level set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.hanging_light_level

# COMMENT THIS OUT LATER (Show max hanging on one side)
$execute positioned $(pos0_x) $(pos0_y) $(pos0_z) facing $(pos1_x) $(pos1_y) $(pos1_z) positioned ^ ^ ^$(half_distance) run function af.base:furniture/place/line/hanging/cast_setup with storage af.base:argument

# Reset storages and scores
data remove storage af.base:argument hanging_distance
data remove storage af.base:argument hanging_count
data remove storage af.base:argument hanging_offset
data remove storage af.base:argument hanging_light_level
scoreboard players reset #hanging_count af.placement_data