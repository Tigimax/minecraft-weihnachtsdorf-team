# Here, do all the crazy stuff, and then remove the marker

# If a player is already placing something, but no marker exists in the world, return and start a new placement
tag @s add af.placement_temp
# Set a flag to if item display exists
execute as @e[type=item_display,sort=nearest,tag=af.placement_marker_0] if score @s af.placement_id = @a[tag=af.placement_temp,limit=1] af.placement_id run scoreboard players set #entity_exists_flag af.placement_data 0
# Remove temporary tag
tag @s remove af.placement_temp
# If flag is hit, run a different function and return
execute unless score #entity_exists_flag af.placement_data matches 0 run function af.base:furniture/place/line/start_place
# Reset flag and return from this function if flag is not hit
execute unless score #entity_exists_flag af.placement_data matches 0 run return fail

# Summons a furniture interaction and item display
summon item_display ~ ~ ~ {Tags:["af.new","af.placement_marker","af.placement_marker_1"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"minecraft:furniture/empty"}}}

# Apply temporary storage in floats
data modify storage af.base:argument Pos0 set value [0f,0f,0f]
data modify storage af.base:argument Pos1 set value [1f,1f,1f]

# Add temporary tag to self
tag @s add af.placement_temp
# Store the coordinates of the new marker in a temporary storage
execute as @e[type=item_display,limit=1,sort=nearest,distance=..64,tag=af.placement_marker_0] if score @s af.placement_id = @a[tag=af.placement_temp,limit=1] af.placement_id run data modify storage af.base:argument Pos0 set from entity @s Pos
execute as @e[type=item_display,limit=1,sort=nearest,distance=..1,tag=af.new] run data modify storage af.base:argument Pos1 set from entity @s Pos
# Remove temporary tag
tag @s remove af.placement_temp

# Calculate distance using provider
data modify storage af.base:argument distance set compute default float af.base:distance_3d
data modify storage af.base:argument half_distance set compute default float af.base:half
# Store the link amount
data modify storage af.base:argument links set compute default float af.base:line/links
execute store result score #links af.placement_data run data get storage af.base:argument links
# Store the length of the last link (and store in score as integer)
data modify storage af.base:argument last_length set compute default float af.base:line/last_length
execute store result score #last_length af.placement_data run data get storage af.base:argument last_length
# Lastly, store the held item as an argument
data modify storage af.base:argument held_item set from storage af.base:furniture held_item

# Prepare any other necessary data to be passed in the argument chain
data modify storage af.base:argument pos0_x set from storage af.base:argument Pos0[0]
data modify storage af.base:argument pos0_y set from storage af.base:argument Pos0[1]
data modify storage af.base:argument pos0_z set from storage af.base:argument Pos0[2]
data modify storage af.base:argument pos1_x set from storage af.base:argument Pos1[0]
data modify storage af.base:argument pos1_y set from storage af.base:argument Pos1[1]
data modify storage af.base:argument pos1_z set from storage af.base:argument Pos1[2]
data modify storage af.base:argument line_length set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.line_length
data modify storage af.base:argument line_model set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.line_model
data modify storage af.base:argument hanging_model set from storage af.base:furniture held_item.components."minecraft:custom_data".line_data.hanging_model

# Remove any unecessary storage from being passed in the chain
data remove storage af.base:argument Pos0
data remove storage af.base:argument Pos1
data remove storage af.base:argument distance
data remove storage af.base:argument links
data remove storage af.base:argument last_length

# COMMENT THIS OUT THIS LATER (Show coordinates in chat)
#tellraw @s [{"text":"Position 0: ["},{"nbt":"Pos0[0]","storage":"af.base:argument"},{"text":", "},{"nbt":"Pos0[1]","storage":"af.base:argument"},{"text":", "},{"nbt":"Pos0[2]","storage":"af.base:argument"},{"text":"]\nPosition 1: ["},{"nbt":"Pos1[0]","storage":"af.base:argument"},{"text":", "},{"nbt":"Pos1[1]","storage":"af.base:argument"},{"text":", "},{"nbt":"Pos1[2]","storage":"af.base:argument"},{"text":"]"}]
#tellraw @s [{"text":"Distance: "},{"nbt":"distance","storage":"af.base:argument"}]
#tellraw @s [{"text":"Half Distance: "},{"nbt":"half_distance","storage":"af.base:argument"}]
#tellraw @s [{"text":"Links: "},{"score":{"name":"#links","objective":"af.placement_data"}}]
#tellraw @s [{"text":"Last Length Size (in units of 0.5): "},{"score":{"name":"#last_length","objective":"af.placement_data"}}]

# Start creating the furniture item using the collected data

# Create a new furniture ID to assign to entities
scoreboard players add #current_id af.furniture_id 1

# Start placement cast
function af.base:furniture/place/line/cast_setup with storage af.base:argument

# Check if there are hanging items and run placement function if so
execute store result score #has_hanging af.placement_data run data get storage af.base:furniture held_item.components."minecraft:custom_data".line_data.has_hanging
execute if score #has_hanging af.placement_data matches 1 run function af.base:furniture/place/line/hanging/place with storage af.base:argument

# As all af.new items, add the furniture id
execute as @e[tag=af.new] run scoreboard players operation @s af.furniture_id = #current_id af.furniture_id

# Remove new tag
tag @e[tag=af.new] remove af.new
# Kill placement marker
kill @e[tag=af.placement_marker_1,type=item_display]

# Remove storage items from af.base:argument (This is also the list of arguments)
data remove storage af.base:argument line_length
data remove storage af.base:argument line_model
data remove storage af.base:argument half_distance
data remove storage af.base:argument max_hanging
data remove storage af.base:argument hanging_model
data remove storage af.base:argument hanging_distance
data remove storage af.base:argument pos0_x
data remove storage af.base:argument pos0_y
data remove storage af.base:argument pos0_z
data remove storage af.base:argument pos1_x
data remove storage af.base:argument pos1_y
data remove storage af.base:argument pos1_z

# Reset scores
scoreboard players reset #has_hanging af.placement_data
scoreboard players reset #links af.placement_data
scoreboard players reset #last_length af.placement_data

# Removes an item from non creative player's hand
execute as @s[gamemode=!creative,predicate=af.base:furniture_offhand] run function af.base:item/remove_offhand
execute as @s[gamemode=!creative,predicate=af.base:furniture_mainhand] run function af.base:item/remove_mainhand

# Signal placement success
scoreboard players set #place_success af.placement_data 0

# Fanfare
title @s actionbar [{"text":"Left Click","color":"#baa7ff"},{"text":" either end of line to collect it.","color":"#ffffff"}]