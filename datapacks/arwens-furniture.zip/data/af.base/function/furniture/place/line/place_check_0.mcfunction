# Try to place line
execute if score @s af.placement_data matches 0 run function af.base:furniture/place/line/place
execute unless score @s af.placement_data matches 0.. run function af.base:furniture/place/line/start_place
# Reset flag made in place
scoreboard players reset #entity_exists_flag af.placement_data

# Remove tags if necessary
execute if score #place_success af.placement_data matches 1 run function af.base:furniture/place/line/cancel_place
execute if score #place_success af.placement_data matches 0 run function af.base:furniture/place/line/remove_marker
# Reset place_success
scoreboard players reset #place_success af.placement_data