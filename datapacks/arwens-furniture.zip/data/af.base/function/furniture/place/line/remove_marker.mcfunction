# Add temporary tag to placement marker
tag @s add af.placement_temp
# If a placement marker associated with the player, remove self
execute as @e[tag=af.placement_marker,type=item_display] if score @s af.placement_id = @a[tag=af.placement_temp,limit=1] af.placement_id run kill @s
# Remove temporary tag
tag @s remove af.placement_temp

# Reset the player's placement data and id
scoreboard players reset @s af.placement_data
scoreboard players reset @s af.placement_id