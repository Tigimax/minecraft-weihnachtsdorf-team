# Tries to find a player matching self
tag @s add af.placement_temp
execute as @a if score @s af.placement_id = @e[tag=af.placement_temp,distance=..0.1,type=item_display,limit=1] af.placement_id at @s run function af.base:furniture/place/line/cancel_place
# Remove temporary tag
tag @s remove af.placement_temp

# Kills self if no player is found
kill @s