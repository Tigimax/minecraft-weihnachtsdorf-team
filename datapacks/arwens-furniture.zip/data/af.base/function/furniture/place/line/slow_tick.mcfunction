# Add 1 to the placement timer
scoreboard players add @s af.placement_timer 1
# Remove self if placement timer reaches 3
execute if score @s af.placement_timer matches 3 run function af.base:furniture/place/line/remove_self