# Summons a furniture interaction and item display
summon item_display ~ ~ ~ {Tags:["af.new","af.placement_marker","af.placement_marker_0"],item:{id:"minecraft:paper",count:1,components:{"minecraft:item_model":"minecraft:furniture/placement/line_marker"}},Glowing:true}

# Creates a new marker ID and assigns it to both the player and new placement marker
scoreboard players add #marker_id af.placement_data 1
scoreboard players operation @s af.placement_id = #marker_id af.placement_data
scoreboard players operation @e[type=item_display,limit=1,sort=nearest,distance=..1,tag=af.new] af.placement_id = #marker_id af.placement_data
scoreboard players set @s af.placement_data 0

# Removes selector tag from all newly created entities
tag @e[tag=af.new] remove af.new

# Fanfare
title @s actionbar [{"text":"Right Click","color":"#baa7ff"},{"text":" second location to place line.","color":"#ffffff"}]
playsound minecraft:block.note_block.hat player @s ~ ~ ~ 1 1.5