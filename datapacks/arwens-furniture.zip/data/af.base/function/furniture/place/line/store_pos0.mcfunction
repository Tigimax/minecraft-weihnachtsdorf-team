# Store position
execute store result storage af.base:argument Pos0[0] float 1 run data get entity @s Pos[0]
execute store result storage af.base:argument Pos0[1] float 1 run data get entity @s Pos[1]
execute store result storage af.base:argument Pos0[2] float 1 run data get entity @s Pos[2]