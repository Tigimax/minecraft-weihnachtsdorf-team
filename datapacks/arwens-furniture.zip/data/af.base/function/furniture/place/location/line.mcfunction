# Checks for slab
scoreboard players set is_slab af.data 0
execute if score cast_face af.data matches 5 store result score is_slab af.data if block ~ ~0.5 ~ #af.base:slabs[type=top]
execute if score cast_face af.data matches 0 store result score is_slab af.data if block ~ ~-0.5 ~ #af.base:slabs[type=top]

## CAST FACE 0 IF NOT SLAB (Floor)
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 0 if score is_slab af.data matches 0 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.5 ~.001 ~.5 run function af.base:furniture/place/line/place_check_0
# Snaps to exact spot downward if player is sneaking
execute if score cast_face af.data matches 0 if score is_slab af.data matches 0 as @s[predicate=af.base:is_sneaking] align y positioned ~ ~.001 ~ run function af.base:furniture/place/line/place_check_0

## CAST FACE 0 IF SLAB (Floor)
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 0 if score is_slab af.data matches 1 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.5 ~-.499 ~.5 run function af.base:furniture/place/line/place_check_0
# Snaps to exact spot downward if player is sneaking
execute if score cast_face af.data matches 0 if score is_slab af.data matches 1 as @s[predicate=af.base:is_sneaking] align y positioned ~ ~-.499 ~ run function af.base:furniture/place/line/place_check_0

## CAST FACE 1
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 1 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.499 ~.5 ~.999 run function af.base:furniture/place/line/place_check_0
# Snaps to wall if sneaking
execute if score cast_face af.data matches 1 as @s[predicate=af.base:is_sneaking] align z positioned ~ ~ ~.999 run function af.base:furniture/place/line/place_check_0

## CAST FACE 2
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 2 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.999 ~.5 ~.499 run function af.base:furniture/place/line/place_check_0
# Snaps to wall if sneaking
execute if score cast_face af.data matches 2 as @s[predicate=af.base:is_sneaking] align x positioned ~.999 ~ ~ run function af.base:furniture/place/line/place_check_0

## CAST FACE 3
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 3 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.499 ~.5 ~.001 run function af.base:furniture/place/line/place_check_0
# Snaps to wall if sneaking
execute if score cast_face af.data matches 3 as @s[predicate=af.base:is_sneaking] align z positioned ~ ~ ~.001 run function af.base:furniture/place/line/place_check_0

## CAST FACE 4
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 4 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.001 ~.5 ~.499 run function af.base:furniture/place/line/place_check_0
# Snaps to wall if sneaking
execute if score cast_face af.data matches 4 as @s[predicate=af.base:is_sneaking] align x positioned ~.001 ~ ~ run function af.base:furniture/place/line/place_check_0

## CAST FACE 5 IF NOT SLAB (Ceiling)
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 5 if score is_slab af.data matches 0 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.5 ~.999 ~.5 run function af.base:furniture/place/line/place_check_0
# Snaps to exact spot downward if player is sneaking
execute if score cast_face af.data matches 5 if score is_slab af.data matches 0 as @s[predicate=af.base:is_sneaking] align y positioned ~ ~.999 ~ run function af.base:furniture/place/line/place_check_0

## CAST FACE 5 IF SLAB (Ceiling)
# Snaps to center of block if player is not sneaking
execute if score cast_face af.data matches 5 if score is_slab af.data matches 1 as @s[predicate=!af.base:is_sneaking] align xyz positioned ~.5 ~1.499 ~.5 run function af.base:furniture/place/line/place_check_0
# Snaps to exact spot downward if player is sneaking
execute if score cast_face af.data matches 5 if score is_slab af.data matches 1 as @s[predicate=af.base:is_sneaking] align y positioned ~ ~1.499 ~ run function af.base:furniture/place/line/place_check_0

# Reset slab score
scoreboard players reset is_slab af.data