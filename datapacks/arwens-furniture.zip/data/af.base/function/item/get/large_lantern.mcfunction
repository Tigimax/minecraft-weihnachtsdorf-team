loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_lantern
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_soul_lantern
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_golden_lantern
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_0
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_1
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_2