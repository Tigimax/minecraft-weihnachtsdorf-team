loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_lantern_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_soul_lantern_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_golden_lantern_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_line_0
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_line_1
loot spawn ~ ~ ~ loot af.base:entities/furniture/lantern/large_copper_lantern_line_2