loot spawn ~ ~ ~ loot af.base:entities/furniture/line/chain_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/line/golden_chain_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/line/copper_chain_line
loot spawn ~ ~ ~ loot af.base:entities/furniture/line/copper_chain_line_0
loot spawn ~ ~ ~ loot af.base:entities/furniture/line/copper_chain_line_1
loot spawn ~ ~ ~ loot af.base:entities/furniture/line/copper_chain_line_2