# Run slow tick functions of other entities
execute as @e[tag=af.placement_marker,type=item_display] at @s run function af.base:furniture/place/line/slow_tick

# Loop this function
schedule function af.base:slow_tick_30s 30s replace