# Cancel placement if player goes too far away from a placement marker
execute as @a[scores={af.placement_data=0..}] at @s unless entity @e[tag=af.placement_marker,distance=..40] run function af.base:furniture/place/line/cancel_place

# Re-call this function
schedule function af.base:slow_tick_5s 5s replace