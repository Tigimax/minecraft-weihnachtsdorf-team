# 2 block/arrow_down_road_sign
# 1 block/park_road_sign
# 5 block/arrow_right_road_sign
# 3 block/arrow_up_road_sign
# 4 block/arrow_left_road_sign
# 0 block/no_entrance_road_sign