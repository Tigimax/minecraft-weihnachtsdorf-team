data modify storage bubblellaneous tmp.out.recipe set value []
execute store result score #length bbln.tmp run data get storage bubblellaneous tmp.in.recipe
execute if score #length bbln.tmp matches 0 run return 0

function bubblellaneous:block/bubble_bench/recipe/generate/loop