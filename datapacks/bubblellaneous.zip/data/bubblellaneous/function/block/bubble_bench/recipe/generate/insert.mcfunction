$data modify storage bubblellaneous tmp.out.recipe append value [ \
			{"text": "› ","color": "gray","italic": false}, \
			{"atlas": "$(texture_atlas)", "sprite": "$(texture)", "color": "white"}, \
			" ", \
			{"translate": "$(unit).minecraft.$(id)","color": "white"}, \
			{"translate": " × $(count)","color": "gold"} \
]
