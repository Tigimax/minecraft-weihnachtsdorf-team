data modify storage bubblellaneous tmp.i set from storage bubblellaneous tmp.in.recipe[0]
data remove storage bubblellaneous tmp.in.recipe[0]

execute unless data storage bubblellaneous tmp.i.texture run function bubblellaneous:block/bubble_bench/recipe/generate/set_assumed_texture with storage bubblellaneous tmp.i
function bubblellaneous:block/bubble_bench/recipe/generate/insert with storage bubblellaneous tmp.i
scoreboard players remove #length bbln.tmp 1
execute if score #length bbln.tmp matches 1.. run function bubblellaneous:block/bubble_bench/recipe/generate/loop