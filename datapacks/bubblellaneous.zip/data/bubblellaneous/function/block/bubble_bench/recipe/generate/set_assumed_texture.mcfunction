$data modify storage bubblellaneous tmp.i.texture_atlas set value "minecraft:$(unit)s"
$data modify storage bubblellaneous tmp.i.texture set value "$(unit)/$(id)"
