data modify storage bubblellaneous tmp.size set from storage bubblellaneous tmp.entry.size
data modify storage bubblellaneous tmp.entry set from storage bubblellaneous tmp.entry.items[0]
data modify storage bubblellaneous tmp.entry.size set from storage bubblellaneous tmp.size