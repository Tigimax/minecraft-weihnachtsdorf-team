function bubblellaneous:block_placer/internal/apply_blockstate {name: "default", rotation: 0}
setblock ~ ~ ~ petrified_oak_slab[type=double]
