tp @a[predicate=bubblellaneous:check/block.id,tag=--bbln.player,limit=1,x=0] ^ ^-1.75 ^0.5 ~ 20
spectate @s @a[predicate=bubblellaneous:check/block.id,tag=--bbln.player,limit=1,x=0]

execute as @e[type=item_display,tag=bbln.name.surveillance_camera,predicate=bubblellaneous:check/block.id,limit=1,x=0] \
	if score @s bbln.var matches 1 \
	as @a[predicate=bubblellaneous:check/block.id,tag=--bbln.player,tag=--bbln.camera.just_entered_camera,limit=1,x=0] \
	run function bubblellaneous:block/surveillance_camera/player/spectate/notify_about_manual_mode