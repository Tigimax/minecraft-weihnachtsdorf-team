#region Lambda
tag @s remove --bbln.camera.just_entered_camera
execute if score @s bbln.player.notification_cooldown matches 1.. run return 0
tellraw @s {"translate":"ui.bubblellaneous.camera.manual_mode", "color":"#fcd78d", "with": [{"keybind": "key.left", "bold":true}, {"keybind": "key.right", "bold":true}, {"keybind": "key.jump", "bold":true}]}
scoreboard players set @s bbln.player.notification_cooldown 600
#endregion