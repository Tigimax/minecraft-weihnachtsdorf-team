setblock ~ ~ ~ air
kill @s