execute summon zombie_nautilus run execute at @s run ride @n[type=drowned,tag=dnt_make_drowned_into_jockey] mount @s
tag @s remove dnt_make_drowned_into_jockey
item replace entity @s saddle with air