execute summon chicken run function nova_structures:jockey/spawn_chicken_jockey_mount
kill @s