execute if predicate {predicate:{structures:"nova_structures:end_castle"},type:"minecraft:location_check"} run tell @s nova_structures:end_castle

execute if predicate {predicate:{structures:"nova_structures:end_lighthouse"},type:"minecraft:location_check"} run tell @s nova_structures:end_lighthouse

execute if predicate {predicate:{structures:"nova_structures:end_ship"},type:"minecraft:location_check"} run tell @s nova_structures:end_ship