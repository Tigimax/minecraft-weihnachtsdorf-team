execute if predicate {predicate:{structures:"#nova_structures:firewatch_tower"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld_firewatch_towers

execute if predicate {predicate:{structures:"#nova_structures:remnants"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld_remnants

execute if predicate {predicate:{structures:"#nova_structures:surface_dungeons"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld_surface_dungeons

execute if predicate {predicate:{structures:"#nova_structures:taverns"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld_taverns

execute if predicate {predicate:{structures:"#nova_structures:wells"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/overworld_wells

execute if predicate {predicate:{structures:"nova_structures:badlands_miner_outpost"},type:"minecraft:location_check"} run tell @s nova_structures:badlands_miner_outpost

execute if predicate {predicate:{structures:"nova_structures:bogged_camp"},type:"minecraft:location_check"} run tell @s nova_structures:bogged_camp

execute if predicate {predicate:{structures:"nova_structures:dappled_townhall"},type:"minecraft:location_check"} run tell @s nova_structures:dappled_townhall

execute if predicate {predicate:{structures:"nova_structures:desert_ruins"},type:"minecraft:location_check"} run tell @s nova_structures:desert_ruins

execute if predicate {predicate:{structures:"nova_structures:illager_barracks"},type:"minecraft:location_check"} run tell @s nova_structures:illager_barracks

execute if predicate {predicate:{structures:"nova_structures:illager_camp"},type:"minecraft:location_check"} run tell @s nova_structures:illager_camp

execute if predicate {predicate:{structures:"nova_structures:illager_manor"},type:"minecraft:location_check"} run tell @s nova_structures:illager_manor

execute if predicate {predicate:{structures:"nova_structures:illager_treehouse"},type:"minecraft:location_check"} run tell @s nova_structures:illager_treehouse

execute if predicate {predicate:{structures:"nova_structures:jungle_ruins"},type:"minecraft:location_check"} run tell @s nova_structures:jungle_ruins

execute if predicate {predicate:{structures:"nova_structures:lone_citadel"},type:"minecraft:location_check"} run tell @s nova_structures:lone_citadel

execute if predicate {predicate:{structures:"nova_structures:mangrove_witch_hut"},type:"minecraft:location_check"} run tell @s nova_structures:mangrove_witch_hut

execute if predicate {predicate:{structures:"nova_structures:pale_residence"},type:"minecraft:location_check"} run tell @s nova_structures:pale_residence

execute if predicate {predicate:{structures:"nova_structures:parched_camp"},type:"minecraft:location_check"} run tell @s nova_structures:parched_camp

execute if predicate {predicate:{structures:"nova_structures:ruin_town"},type:"minecraft:location_check"} run tell @s nova_structures:ruin_town

execute if predicate {predicate:{structures:"nova_structures:shrine_tower"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_tower

execute if predicate {predicate:{structures:"nova_structures:stray_camp"},type:"minecraft:location_check"} run tell @s nova_structures:stray_camp

execute if predicate {predicate:{structures:"nova_structures:stray_fort"},type:"minecraft:location_check"} run tell @s nova_structures:stray_fort

execute if predicate {predicate:{structures:"nova_structures:stray_outlook"},type:"minecraft:location_check"} run tell @s nova_structures:stray_outlook

execute if predicate {predicate:{structures:"nova_structures:toxic_lair"},type:"minecraft:location_check"} run tell @s nova_structures:toxic_lair

execute if predicate {predicate:{structures:"nova_structures:village_birch"},type:"minecraft:location_check"} run tell @s nova_structures:village_birch

execute if predicate {predicate:{structures:"nova_structures:village_dappled"},type:"minecraft:location_check"} run tell @s nova_structures:village_dappled

execute if predicate {predicate:{structures:"nova_structures:village_jungle"},type:"minecraft:location_check"} run tell @s nova_structures:village_jungle

execute if predicate {predicate:{structures:"nova_structures:village_swamp"},type:"minecraft:location_check"} run tell @s nova_structures:village_swamp

execute if predicate {predicate:{structures:"nova_structures:wild_ruin"},type:"minecraft:location_check"} run tell @s nova_structures:wild_ruin

execute if predicate {predicate:{structures:"nova_structures:witch_villa"},type:"minecraft:location_check"} run tell @s nova_structures:witch_villa