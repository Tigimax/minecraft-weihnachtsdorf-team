execute if predicate {predicate:{structures:"nova_structures:remnant_bee_keeper"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_bee_keeper

execute if predicate {predicate:{structures:"nova_structures:remnant_big_remnant"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_big_remnant

execute if predicate {predicate:{structures:"nova_structures:remnant_big_remnant_2"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_big_remnant_2

execute if predicate {predicate:{structures:"nova_structures:remnant_big_remnant_3"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_big_remnant_3

execute if predicate {predicate:{structures:"nova_structures:remnant_birch_graveyard"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_birch_graveyard

execute if predicate {predicate:{structures:"nova_structures:remnant_bridge_remnant"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_bridge_remnant

execute if predicate {predicate:{structures:"nova_structures:remnant_bunny_base"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_bunny_base

execute if predicate {predicate:{structures:"nova_structures:remnant_classic_village"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_classic_village

execute if predicate {predicate:{structures:"nova_structures:remnant_creeper_homestead"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_creeper_homestead

execute if predicate {predicate:{structures:"nova_structures:remnant_desert_remnant"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_desert_remnant

execute if predicate {predicate:{structures:"nova_structures:remnant_forest_smith"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_forest_smith

execute if predicate {predicate:{structures:"nova_structures:remnant_frog_ranch"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_frog_ranch

execute if predicate {predicate:{structures:"nova_structures:remnant_graveyard"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_graveyard

execute if predicate {predicate:{structures:"nova_structures:remnant_lava_chicken"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_lava_chicken

execute if predicate {predicate:{structures:"nova_structures:remnant_lone_shrine_sentinel"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_lone_shrine_sentinel

execute if predicate {predicate:{structures:"nova_structures:remnant_medium_remnant"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_medium_remnant

execute if predicate {predicate:{structures:"nova_structures:remnant_medium_remnant_2"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_medium_remnant_2

execute if predicate {predicate:{structures:"nova_structures:remnant_miner_hut"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_miner_hut

execute if predicate {predicate:{structures:"nova_structures:remnant_mud_brick_constructor"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_mud_brick_constructor

execute if predicate {predicate:{structures:"nova_structures:remnant_ominous_shop"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_ominous_shop

execute if predicate {predicate:{structures:"nova_structures:remnant_ruin_farmer"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_ruin_farmer

execute if predicate {predicate:{structures:"nova_structures:remnant_ruin_smith"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_ruin_smith

execute if predicate {predicate:{structures:"nova_structures:remnant_sawmill"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_sawmill

execute if predicate {predicate:{structures:"nova_structures:remnant_school_remnant"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_school_remnant

execute if predicate {predicate:{structures:"nova_structures:remnant_shrine_research_station"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_shrine_research_station

execute if predicate {predicate:{structures:"nova_structures:remnant_shrine_sentinel_mass_grave"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_shrine_sentinel_mass_grave

execute if predicate {predicate:{structures:"nova_structures:remnant_taiga_castle"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_taiga_castle

execute if predicate {predicate:{structures:"nova_structures:remnant_woodland_hud"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_woodland_hud

execute if predicate {predicate:{structures:"nova_structures:remnant_youth_spring"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_youth_spring

execute if predicate {predicate:{structures:"nova_structures:remnant_zombie_horse_ranch"},type:"minecraft:location_check"} run tell @s nova_structures:remnant_zombie_horse_ranch