execute if predicate {predicate:{structures:"#nova_structures:cave_chambers"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/underground_cave_chambers

execute if predicate {predicate:{structures:"#nova_structures:shrine"},type:"minecraft:location_check"} run function nova_structures:structure_search/dnt/underground_shrines

execute if predicate {predicate:{structures:"nova_structures:shrine_combat_tier_6"},type:"minecraft:location_check"} run tell @s nova_structures:shrine_combat_tier_6

execute if predicate {predicate:{structures:"nova_structures:bunker"},type:"minecraft:location_check"} run tell @s nova_structures:bunker

execute if predicate {predicate:{structures:"nova_structures:catacomb"},type:"minecraft:location_check"} run tell @s nova_structures:catacomb

execute if predicate {predicate:{structures:"nova_structures:cave_hut"},type:"minecraft:location_check"} run tell @s nova_structures:cave_hut

execute if predicate {predicate:{structures:"nova_structures:creeping_crypt"},type:"minecraft:location_check"} run tell @s nova_structures:creeping_crypt

execute if predicate {predicate:{structures:"nova_structures:deepslate_camp"},type:"minecraft:location_check"} run tell @s nova_structures:deepslate_camp

execute if predicate {predicate:{structures:"nova_structures:illager_hideout"},type:"minecraft:location_check"} run tell @s nova_structures:illager_hideout

execute if predicate {predicate:{structures:"#nova_structures:mineshafts_jaggedpeak"},type:"minecraft:location_check"} run tell @s nova_structures:mineshaft_jaggedpeak

execute if predicate {predicate:{structures:"#nova_structures:mineshafts_stonepeak"},type:"minecraft:location_check"} run tell @s nova_structures:mineshaft_stonepeak

execute if predicate {predicate:{structures:"#nova_structures:mineshafts_surface"},type:"minecraft:location_check"} run tell @s nova_structures:mineshaft_surface

execute if predicate {predicate:{structures:"nova_structures:small_creeping_crypt"},type:"minecraft:location_check"} run tell @s nova_structures:small_creeping_crypt

execute if predicate {predicate:{structures:"nova_structures:small_undead_crypt"},type:"minecraft:location_check"} run tell @s nova_structures:small_undead_crypt

execute if predicate {predicate:{structures:"nova_structures:trial_dungeon"},type:"minecraft:location_check"} run tell @s nova_structures:trial_dungeon

execute if predicate {predicate:{structures:"nova_structures:undead_crypt"},type:"minecraft:location_check"} run tell @s nova_structures:undead_crypt

execute if predicate {predicate:{structures:"nova_structures:underground_house"},type:"minecraft:location_check"} run tell @s nova_structures:underground_house