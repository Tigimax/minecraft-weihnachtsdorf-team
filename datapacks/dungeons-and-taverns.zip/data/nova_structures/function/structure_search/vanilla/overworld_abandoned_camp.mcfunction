execute if predicate {predicate:{structures:"minecraft:abandoned_camp_bamboo_jungle"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_bamboo_jungle

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_birch_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_birch_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_cherry_grove"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_cherry_grove

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_dappled_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_dappled_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_flower_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_flower_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_meadow"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_meadow

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_old_growth_birch_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_old_growth_birch_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_old_growth_pine_taiga"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_old_growth_pine_taiga

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_old_growth_spruce_taiga"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_old_growth_spruce_taiga

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_pale_garden"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_pale_garden

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_savanna"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_savanna

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_snowy_taiga"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_snowy_taiga

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_sparse_jungle"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_sparse_jungle

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_swamp"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_swamp

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_taiga"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_taiga

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_windswept_forest"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_windswept_forest

execute if predicate {predicate:{structures:"minecraft:abandoned_camp_wooded_badlands"},type:"minecraft:location_check"} run tell @s minecraft:abandoned_camp_wooded_badlands