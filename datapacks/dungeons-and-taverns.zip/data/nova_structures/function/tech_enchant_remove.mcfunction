item modify entity @s nova_structures:tech_enchant_find nova_structures:tech_enchant_fix

advancement revoke @s only nova_structures:tech_enchant_remover