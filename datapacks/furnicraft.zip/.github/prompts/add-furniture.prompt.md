---
description: "FurniCraft'e yeni mobilya eklemek için loot-table-first iş akışı"
argument-hint: "Mobilya adı, özel taglar, type/color ve head value bilgileri"
agent: "agent"
---

FurniCraft deposuna yeni mobilya ekle.

Önce loot table yapısını incele ve istekten şu bilgileri netleştir:
- Mobilya adı
- Loot table'da kullanılacak taglar:
	- `furniture:1b` default olmalı
	- `chair1`, `table1` gibi özel mobilya tagı varsa onu da al
	- varsa `type` değeri örneğin `oak:1b`
	- varsa `color` değeri
- Player head veya headlerin `minecraft:profile` `value` değeri
- Bu mobilya tek parçalı mı, çok parçalı mı
- Kategori: sandalye, masa, dolap, lamba, perde, posta kutusu, raf, bench veya benzeri
- Katalogda görünmesi gerekip gerekmediği
- Carpenter bench ile craftlanacaksa hangi itemlerle craftlandığını, hangi slotlarda kullanıldığını ve type'a göre hangi sonuç iteminin üretileceğini netleştir

Sonra şu akışı izle:
1. `data/ketket_furnitures/loot_table/**` içindeki benzer mobilyaları bul ve loot table şemasını onlardan kopyala.
2. Yeni mobilya için loot table itemını oluştur; custom_data içinde en az `furniture:1b` ve ilgili özel tagları kullan, gerekiyorsa `type` ve `color` alanlarını ekle.
3. Head texture için doğru `minecraft:profile.properties.value` bilgisini al ve itemı bununla üret.
4. Aynı mobilyanın `place/` ve `remover/` akışını mevcut örneklerden takip et.
5. Player head üzerindeki tagtan mobilya tipi anlaşılmalı; ardından yön belirlenmeli ve doğru `place` dosyası çalışmalı.
6. Yerleştirme dosyasında temel olarak ilgili `interaction` entitysini oluşturman yeterli; görsel/tasarım detaylarını ben sonradan tamamlayacağım.
7. Eğer mobilya `blockchecker` özelliğine sahipse bunu özellikle sor ve `tickfunc/blockchecker.mcfunction` ile sökme kontrolüne bağla.
8. Aynı block detection mantığını koru: block hasarı veya eksik blok varsa ilgili remover akışı çalışmalı.
9. Sökme fonksiyonunu diğer mobilyalarla benzer yapıda oluştur; gerekiyorsa item geri verme ve cleanup adımlarını ekle.
10. Carpenter bench gerektiriyorsa `data/ketket_furnitures/function/carpenterbench/**` akışını incele; `detecttype`, `menu/*`, `craft/*`, `itemcraft`, `menuset`, `slot9`, `slot10` ve `return/*` zincirini takip et.
11. Carpenter bench için hangi input item ile craft yapılacağını bilmiyorsan önce bunu bana sor; type'a göre doğru craft sonucunu seçmeden ilerleme.

Çalışmayı bitirirken şu çıktıyı ver:
- Kısa özet
- Değişen dosyalar
- Yerleştirme akışında yapılan değişiklikler
- Sökme akışında yapılan değişiklikler
- Doğrulama notları ve varsa kalan riskler

Öncelik sırası:
- Mevcut akışı bozmadan en küçük değişiklik
- Kategoriye uygun örneği yeniden kullanma
- Yeni mobilyanın katalog, yerleştirme ve sökme zincirinde eksiksiz bağlı olması