execute as @e[tag=justspawn,type=block_display,tag=log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.log"}
execute as @e[tag=justspawn,type=block_display,tag=planks] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.planks"}
execute as @e[tag=justspawn,type=block_display,tag=plank] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.planks"}
execute as @e[tag=justspawn,type=block_display,tag=wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.stripped_wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.stripped_log"}

execute as @e[tag=justspawn,type=block_display,tag=fence] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.fence"}
execute as @e[tag=justspawn,type=block_display,tag=fence_gate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.fence_gate"}
execute as @e[tag=justspawn,type=block_display,tag=button] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.button"}
execute as @e[tag=justspawn,type=block_display,tag=trapdoor] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.trapdoor"}
execute as @e[tag=justspawn,type=block_display,tag=door] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.door"}
execute as @e[tag=justspawn,type=block_display,tag=pressure_plate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.acacia.pressure_plate"}

execute as @e[tag=justspawn,type=interaction] run tag @s add acacia