execute as @e[tag=justspawn,type=block_display,tag=log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.log"}
execute as @e[tag=justspawn,type=block_display,tag=planks] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.planks"}
execute as @e[tag=justspawn,type=block_display,tag=plank] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.planks"}
execute as @e[tag=justspawn,type=block_display,tag=wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.stripped_wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.stripped_log"}

execute as @e[tag=justspawn,type=block_display,tag=fence] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.fence"}
execute as @e[tag=justspawn,type=block_display,tag=fence_gate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.fence_gate"}
execute as @e[tag=justspawn,type=block_display,tag=button] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.button"}
execute as @e[tag=justspawn,type=block_display,tag=trapdoor] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.trapdoor"}
execute as @e[tag=justspawn,type=block_display,tag=door] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.door"}
execute as @e[tag=justspawn,type=block_display,tag=pressure_plate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.birch.pressure_plate"}

execute as @e[tag=justspawn,type=interaction] run tag @s add birch