execute as @e[tag=justspawn,type=block_display,tag=log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.log"}
execute as @e[tag=justspawn,type=block_display,tag=planks] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.planks"}
execute as @e[tag=justspawn,type=block_display,tag=plank] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.planks"}
execute as @e[tag=justspawn,type=block_display,tag=wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.stripped_wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.stripped_log"}

execute as @e[tag=justspawn,type=block_display,tag=fence] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.fence"}
execute as @e[tag=justspawn,type=block_display,tag=fence_gate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.fence_gate"}
execute as @e[tag=justspawn,type=block_display,tag=button] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.button"}
execute as @e[tag=justspawn,type=block_display,tag=trapdoor] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.trapdoor"}
execute as @e[tag=justspawn,type=block_display,tag=door] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.door"}
execute as @e[tag=justspawn,type=block_display,tag=pressure_plate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.cherry.pressure_plate"}

execute as @e[tag=justspawn,type=interaction] run tag @s add cherry