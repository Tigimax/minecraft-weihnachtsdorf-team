execute as @e[tag=justspawn,type=block_display,tag=log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.log"}
execute as @e[tag=justspawn,type=block_display,tag=planks] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.planks"}
execute as @e[tag=justspawn,type=block_display,tag=plank] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.planks"}
execute as @e[tag=justspawn,type=block_display,tag=wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.stripped_wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.stripped_log"}

execute as @e[tag=justspawn,type=block_display,tag=fence] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.fence"}
execute as @e[tag=justspawn,type=block_display,tag=fence_gate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.fence_gate"}
execute as @e[tag=justspawn,type=block_display,tag=button] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.button"}
execute as @e[tag=justspawn,type=block_display,tag=trapdoor] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.trapdoor"}
execute as @e[tag=justspawn,type=block_display,tag=door] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.door"}
execute as @e[tag=justspawn,type=block_display,tag=pressure_plate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.dark_oak.pressure_plate"}

execute as @e[tag=justspawn,type=interaction] run tag @s add dark_oak
execute as @e[tag=justspawn,type=interaction] run tag @s add darkoak