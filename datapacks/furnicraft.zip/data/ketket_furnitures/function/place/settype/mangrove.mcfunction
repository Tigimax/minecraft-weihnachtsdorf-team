execute as @e[tag=justspawn,type=block_display,tag=log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.log"}
execute as @e[tag=justspawn,type=block_display,tag=planks] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.planks"}
execute as @e[tag=justspawn,type=block_display,tag=plank] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.planks"}
execute as @e[tag=justspawn,type=block_display,tag=wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_wood] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.stripped_wood"}
execute as @e[tag=justspawn,type=block_display,tag=stripped_log] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.stripped_log"}

execute as @e[tag=justspawn,type=block_display,tag=fence] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.fence"}
execute as @e[tag=justspawn,type=block_display,tag=fence_gate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.fence_gate"}
execute as @e[tag=justspawn,type=block_display,tag=button] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.button"}
execute as @e[tag=justspawn,type=block_display,tag=trapdoor] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.trapdoor"}
execute as @e[tag=justspawn,type=block_display,tag=door] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.door"}
execute as @e[tag=justspawn,type=block_display,tag=pressure_plate] run function ketket_furnitures:internal/block_state/from_storage {storage:"typeholder",path:"type.mangrove.pressure_plate"}

execute as @e[tag=justspawn,type=interaction] run tag @s add mangrove