execute if block ~ ~ ~ player_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}
execute if block ~ ~ ~ player_wall_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}

execute positioned ~ ~1 ~ if block ~ ~ ~ player_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}
execute positioned ~ ~-1 ~ if block ~ ~ ~ player_wall_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}
execute positioned ~ ~-1 ~ if block ~ ~ ~ player_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}
execute positioned ~ ~-1 ~ if block ~ ~ ~ player_wall_head run return run execute align xyz positioned ~0.5 ~ ~0.5 run summon minecraft:marker ~ ~ ~ {Tags:["sumfurniture"]}
