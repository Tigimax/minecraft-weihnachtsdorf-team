Just a small datapack that removes vanilla mineshafts from generating, in case you don't like the vanilla structures.
