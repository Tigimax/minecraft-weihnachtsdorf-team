Just a small datapack that removes vanilla ocean ruins from generating, in case you don't like the vanilla structures.
