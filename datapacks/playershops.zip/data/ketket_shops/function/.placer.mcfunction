scoreboard players set @s isPlaced 1
execute if data entity @s SelectedItem run scoreboard players set @s .isPlaced 0
function ketket_shops:tickfunc/placedetector