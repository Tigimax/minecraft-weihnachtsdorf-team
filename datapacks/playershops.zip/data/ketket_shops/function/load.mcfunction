tellraw @a ["","[",{"text":"Player Shops v4.7","color":"gold"},"] ",{"text":"Datapack has been reloaded. Check if there is a new version available. ","color":"green"},{"text":"Modrinth","underlined":true,"color":"white",click_event:{"action":"open_url","url":"https://modrinth.com/datapack/ketkets-player-shops"}}]

scoreboard objectives add .isPlaced minecraft.used:minecraft.player_head
scoreboard objectives add isPlaced minecraft.used:minecraft.player_head
scoreboard objectives add ket.place trigger
scoreboard objectives add ket.bool dummy

scoreboard objectives add totalearn dummy
scoreboard objectives add totalearn_msg dummy

scoreboard objectives add totalstock dummy
scoreboard objectives add totalstock_holder dummy
scoreboard objectives add totalstock_upgrade dummy
scoreboard objectives add totalstock_chestcount dummy
scoreboard objectives add totalstock_chestcount_holder dummy
scoreboard objectives add currentstock dummy
scoreboard objectives add currentstock_msg dummy

scoreboard objectives add currentstock_add dummy

scoreboard objectives add unique_shopid dummy
scoreboard players add #unique_shopid unique_shopid 0

scoreboard objectives add boolean_shop dummy
scoreboard objectives add product_price dummy
scoreboard objectives add product_count dummy
scoreboard objectives add product_countholder dummy
scoreboard objectives add pay_price dummy
scoreboard objectives add return_price dummy

scoreboard objectives add product_pricedisp dummy
scoreboard objectives add product_countdisp dummy

scoreboard objectives add glass_dye dummy
scoreboard objectives add carpet_dye dummy
scoreboard objectives add wool_dye dummy

scoreboard objectives add shop_page dummy

scoreboard objectives add Sneaking_ps minecraft.custom:minecraft.sneak_time

scoreboard objectives add math.division dummy

data modify storage ownerfaceholder Owner set value [{}]

data modify storage productfaceholder Product set value [{}]
data modify storage productfaceholder Producttag set value [{}]