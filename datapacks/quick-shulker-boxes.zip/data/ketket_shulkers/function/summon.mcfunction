tag @s add ket.holder
summon chest_minecart ~ ~1 ~ {DisplayState:{id:"minecraft:shulker_box"},CustomName:'Shulker Box',Passengers:[{id:"minecraft:marker",PortalCooldown:-1,Tags:["ket.shulker","justspawn"],data:{Items:[],hand:[],slot:[],x:0,for:26}},{PortalCooldown:-1,Tags:["ket.shulker","justspawn"],id:"minecraft:block_display",block_state:{id:"minecraft:shulker_box",properties:{}},transformation:[1.2500f,0.0000f,0.0000f,-0.6250f,0.0000f,1.2500f,0.0000f,-0.2000f,0.0000f,0.0000f,1.2500f,-0.6250f,0.0000f,0.0000f,0.0000f,1.0000f]}],NoGravity:1b,Silent:1b,Invulnerable:1b,PortalCooldown:-1,Tags:["ket.shulker","justspawn"],Items:[{count:1,Slot:0b,id:"minecraft:knowledge_book"},{count:1,Slot:1b,id:"minecraft:knowledge_book"},{count:1,Slot:2b,id:"minecraft:knowledge_book"},{count:1,Slot:3b,id:"minecraft:knowledge_book"},{count:1,Slot:4b,id:"minecraft:knowledge_book"},{count:1,Slot:5b,id:"minecraft:knowledge_book"},{count:1,Slot:6b,id:"minecraft:knowledge_book"},{count:1,Slot:7b,id:"minecraft:knowledge_book"},{count:1,Slot:8b,id:"minecraft:knowledge_book"},{count:1,Slot:9b,id:"minecraft:knowledge_book"},{count:1,Slot:10b,id:"minecraft:knowledge_book"},{count:1,Slot:11b,id:"minecraft:knowledge_book"},{count:1,Slot:12b,id:"minecraft:knowledge_book"},{count:1,Slot:13b,id:"minecraft:knowledge_book"},{count:1,Slot:14b,id:"minecraft:knowledge_book"},{count:1,Slot:15b,id:"minecraft:knowledge_book"},{count:1,Slot:16b,id:"minecraft:knowledge_book"},{count:1,Slot:17b,id:"minecraft:knowledge_book"},{count:1,Slot:18b,id:"minecraft:knowledge_book"},{count:1,Slot:19b,id:"minecraft:knowledge_book"},{count:1,Slot:20b,id:"minecraft:knowledge_book"},{count:1,Slot:21b,id:"minecraft:knowledge_book"},{count:1,Slot:22b,id:"minecraft:knowledge_book"},{count:1,Slot:23b,id:"minecraft:knowledge_book"},{count:1,Slot:24b,id:"minecraft:knowledge_book"},{count:1,Slot:25b,id:"minecraft:knowledge_book"},{count:1,Slot:26b,id:"minecraft:knowledge_book"}]}
summon minecraft:interaction ~ ~ ~ {height:0.05f,width:0.05f,Tags:["ket.shulker","justspawn","ket.lock"]}

scoreboard players operation @e[tag=ket.shulker,tag=justspawn,sort=nearest] ket.ID = @s ket.ID
execute store result entity @e[type=marker,tag=justspawn,sort=nearest,limit=1] data.x int 1 run scoreboard players get @s ket.ID



scoreboard players set @s ket.bool 0
function ketket_shulkers:writer/write with entity @e[type=marker,tag=ket.shulker,limit=1,sort=nearest] data

execute as @e[tag=justspawn] run tag @s remove justspawn
