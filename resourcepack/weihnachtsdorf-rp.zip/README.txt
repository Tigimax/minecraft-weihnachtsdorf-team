This is a Minecraft resource pack containing a series of 3D models / textures created for the datapack Arwen's Furniture 2 and its extensions.

Some GLSL code is modified from code written by Mojang Studios.